package com.edu.miu.cs.cs425.eregistrar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ERegistrarApplicationTests {

    @Test
    void contextLoads() {
    }

}
